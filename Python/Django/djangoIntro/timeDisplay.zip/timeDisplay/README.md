# Time Display

This project practices setting up a Django project, passing data to a template,and connecting to static files.

This project completes the following tasks:

1. Create a new project with a single app

2. Have the root route display the current date and time

3. Incorporate your own custom stylesheet

4. NINJA BONUS: Come up with a different way to retrieve the datetime

Created On: May 11, 2020\
Uploaded to Github: July 2, 2020

