# Users with Bank Accounts

This project updates the existing User project to have an association with the BankAccount class.\

This project performs the following tasks:\

1. Update the User class __init__ method
2. Update the User class make_deposit method
3. Update the User class make_withdrawal method
4. Update the User class display_user_balance method
5. SENSEI BONUS: Allow a user to have multiple accounts; update methods so the user has to specify which account they are withdrawing or depositing to

Created On: May 15, 2020\
Pushed to Github: July 1, 2020