# Chaining Methods

This project practices chaining:\

Created On: May 6, 2020\
Pushed to Github: July 1, 2020