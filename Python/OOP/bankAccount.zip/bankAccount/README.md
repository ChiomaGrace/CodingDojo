# Banking Account

This project performs the following tasks:\

1. Create a BankAccount class with the attributes interest rate and balance

2. Add a deposit method to the BankAccount class

3. Add a withdraw method to the BankAccount class

4. Add a display_account_info method to the BankAccount class

5. Add a yield_interest method to the BankAccount class

6. Create 2 accounts

7. To the first account, make 3 deposits and 1 withdrawal, then yield interest and display the account's info all in one line of code (i.e. chaining)

8. To the second account, make 2 deposits and 4 withdrawals, then yield interest and display the account's info all in one line of code (i.e. chaining)

Created On: May 6, 2020\
Pushed to Github: July 1, 2020