# Functions Intermediate II

This project helps practice writing functions and looping over dictionaries to achieve a better understanding of how to traverse through a list of dictionaries or through a dictionary of lists\

Created On: May 5, 2020\
Pushed to Github: July 1, 2020