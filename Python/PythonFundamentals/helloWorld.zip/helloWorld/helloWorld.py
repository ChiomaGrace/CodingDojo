
# 1. TASK: print "Hello World"
print( "Hello World !" )
# 2. print "Hello Noelle!" with the name in a variable
name = "Chioma"
print("Hello", name, "!" )	# with a comma
print("Hello " + name, "!")	# with a +
# 3. print "Hello 42!" with the number in a variable
num = 18
print( "Hello", num )	# with a comma
print("Hello str(num) !") #you can get rid of this error like this changing the num to a string 
fave_food1 = "hibachi"
fave_food2 = "Nigerian food"
print("I love to eat {} and {}.".format(fave_food1, fave_food2)) # with .format()
print(f" I love to eat {fave_food1} and {fave_food2}") # with an f string

# The Hello World Assignment
