# Hello World
A project that practices string concatenation.\
Created On: May 4, 2020\
Pushed to Github: July 1, 2020