class Project 
    attr_accessor :projectName, :projectDescription #getter method

    def initialize name, description #setter method
        @projectName = name
        @projectDescription = description
        @projectPitch = []
    end

    def criteriaForElevatorPitch(name, description)
        @projectPitch << name
        @projectPitch << description # << is the append method
        return @projectPitch
    end

    def elevatorPitch
        @projectPitch
    end

end
