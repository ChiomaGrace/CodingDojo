FactoryBot.define do
  factory :user do
    firstName { "MyString" }
    lastName { "MyString" }
    email { "MyString" }
  end
end
