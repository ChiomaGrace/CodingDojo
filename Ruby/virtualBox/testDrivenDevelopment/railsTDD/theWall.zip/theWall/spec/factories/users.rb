FactoryBot.define do
  factory :user do
    username { "Chioma Ubogagu" }
  end
end
