Rails.application.routes.draw do

# USER ROUTES #

  root 'users#new'

  get 'users/new' => "users#new"
  
  post 'users' => "users#create"

  get 'users/:id' => "users#show"
  
  get 'users/:id/:edit' => "users#edit"

  patch 'users/:id' => "users#update"

  get 'users/:id' => "users#destroy"


  # SESSION ROUTES #

  post 'sessions/create' => "sessions#create" 
  
  delete 'sessions/:id' => "sessions#destroy"


    # IDEA ROUTES #

  get 'ideas' => "ideas#index"

  post 'ideas' => "ideas#create"

  get 'ideas/:id' => "ideas#show"

  delete '/ideas/:id' => "ideas#destroy"

  # LIKE ROUTES #

  post '/ideas/:id/likes' => "likes#create"

  


end
