require 'test_helper'

class LikesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
