class LikesController < ApplicationController
    before_action :findIdea #only way to like an idea is to have locate an idea to like.

    def create #this is like creating a normal feature with a form. Then pass through the two keys/values you need to link in order to create a like
        newLike = Like.create(idea: findIdea, user: currentUser)
        if newLike.errors.any?
            flash[:errors] = ["Error","You cannot like an idea more than once."]
            redirect_to "/ideas" and return #need return to return the value aka the error messages
        end
        redirect_to "/ideas"
    end

private
    def findIdea
        Idea.find(params[:id])
    end
end
