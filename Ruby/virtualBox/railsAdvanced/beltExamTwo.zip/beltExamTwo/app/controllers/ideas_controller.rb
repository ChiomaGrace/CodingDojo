class IdeasController < ApplicationController
  def index
    @allIdeas = Idea.order('likes_count DESC')
    if flash[:errors]
      @errors = flash[:errors] 
    end
  end

  def create
    newIdea = Idea.create(content: ideaParams[:content], user: currentUser)
    redirect_to "/ideas"
  end

  def show
    @specificIdea = Idea.find(params[:id])
    @allLikes = @specificIdea.users.uniq #this query is posssible because of the relationship you added in the idea models that has many users through likes. Could do a query in the console like Idea.find(3).users which would display all th users that liked that idea.
    # Idea.find(params[:id]).users would have also worked. same thing
  end

  def destroy
    Idea.destroy(params[:id])
    redirect_to "/ideas"
  end

  private
  def ideaParams
    params.require(:idea).permit(:content) #pass everything from the form you want in order for it to be in the database
  end
end
