class User < ActiveRecord::Base
  has_secure_password
  has_many :ideas #the ideas the user created
  has_many :likes, dependent: :destroy #the likes the user outsources
  has_many :ideasLikes, through: :likes, source: :ideas #representing the likes table and the ideas the user has with this source
  validates :firstName, :lastName, :alias, :emailAddress, presence: true
  validates :password, length: {minimum: 8}, presence: true
  EMAIL_REGEX = /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]+)\z/i
  validates :emailAddress, presence: true, uniqueness: {case_sensitive:false}, format: {with: EMAIL_REGEX}
end
