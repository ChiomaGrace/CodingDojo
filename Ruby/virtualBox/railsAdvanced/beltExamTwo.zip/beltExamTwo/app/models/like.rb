class Like < ActiveRecord::Base
  belongs_to :user
  belongs_to :idea, :counter_cache => true
  validates_uniqueness_of :user_id, :scope => [:idea_id]
end
