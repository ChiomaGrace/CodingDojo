require 'test_helper'

class SongsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
