require 'test_helper'

class JoinsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
