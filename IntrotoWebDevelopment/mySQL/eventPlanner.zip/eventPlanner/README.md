# Event Planner

Create an ERD to represent the database for an application that allows users to plan events and rsvp to others' events.

Each event should have a title, a description, location, a start time, and an end time. Each user should have a name and an address.

Created On: April 30, 2020\
Uploaded to Github: June 30, 2020

