# Books

Create an ERD to represent the database for an application that tracks users, books, and user's favorite books.

Each book should have a title and an author, and each user should be able to save a list of their favorite books.

Created On: April 30, 2020\
Uploaded to Github: June 30, 2020

