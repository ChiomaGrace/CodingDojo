# User Dashboard

Create an ERD to represent the database for an application that allows users to create posts and create comments.

Created On: May 3, 2020\
Uploaded to Github: July 1, 2020

