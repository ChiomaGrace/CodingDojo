# jQuery Functions
This project creates a web page that uses the following jQuery functions:
* click
* hide
* show
* toggle
* slideDown
* slideUp
* slideToggle
* fadeIn
* fadeOut
* addClass
* before
* after
* append
* html
* attr
* val
* text\
Created On: May 3, 2020\
Uploaded to Github: June 30, 2020

