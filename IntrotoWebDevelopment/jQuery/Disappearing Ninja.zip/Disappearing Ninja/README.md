# Disappearing Ninja
Create a simple HTML page with 8 images of equal width and height (you can use any image you like). When a particular image is clicked, have that image disappear. Also, include a button on the bottom of the page called 'Restore'. When the button is clicked, all images will appear.\
Created On: May 3, 2020\
Uploaded to Github: June 30, 2020

