# JavaScript Basics
A project that recreates the image titled "JavaScript Basics Preview" by using HTML and CSS.\
Created On: April 22, 2020\
Pushed to Github: June 30, 2020