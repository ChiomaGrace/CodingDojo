# Simply Responsive
A responsive web design project that recreates the image titled "Simply Responsive Preview (Screen Size)" by using HTML and CSS.\
Created On: April 24, 2020\
Pushed to Github: June 30, 2020