# Plotting Your Blocks
A project that recreates the image titled "Plotting Your Blocks Preview" by using HTML and CSS.\
Created On: April 21, 2020\
Pushed to Github: June 30, 2020