# Python
A project that recreates the image titled "Python Preview" by using HTML and CSS.\
Created On: April 24, 2020\
Pushed to Github: June 30, 2020