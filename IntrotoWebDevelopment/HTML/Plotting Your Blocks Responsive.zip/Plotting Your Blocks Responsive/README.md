# Plotting Your Blocks Responsive
A responsive web design project that recreates the image titled "Plotting Your Blocks Responsive (Screen Size)" by using HTML and CSS.\
Created On: April 21, 2020\
Pushed to Github: June 30, 2020