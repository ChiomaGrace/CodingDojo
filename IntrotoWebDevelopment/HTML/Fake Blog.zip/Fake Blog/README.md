# Fake Blog
A fake blog using only HTML.\
Created On: April 21, 2020\
Pushed to Github: June 30, 2020