# Internet
A project that recreates the image titled "Internet Preview" by using HTML and CSS.\
Created On: April 26, 2020\
Pushed to Github: June 30, 2020