# Registration Form
A registration form using only HTML.\
Created On: April 20, 2020\
Pushed to Github: June 30, 2020