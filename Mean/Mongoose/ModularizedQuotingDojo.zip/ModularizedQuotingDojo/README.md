# Quoting Dojo

This project performs the following tasks:

1.  Build a simple app that allows users to add quotes to a database and display them on a separate page.

2. The 'add my quote' button should add the user's quote to the database, but the 'skip to quotes' button should take the user directly to the main page.

3. GET ' / ' for the screen on top

4. POST '/quotes' for the method of the form to make a new quote.

5. GET '/quotes' for the screen on the right (where all the quotes are rendered).

Start Date: September 7, 2020\
Pushed to Github: September 7, 2020