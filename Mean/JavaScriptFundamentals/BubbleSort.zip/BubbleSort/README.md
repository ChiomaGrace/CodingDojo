# Bubble Sort

This project performs the following tasks:

1. A classic sorting algorithm

2. Nested loops

Created On: July 14, 2020\
Pushed to Github: July 21, 2020