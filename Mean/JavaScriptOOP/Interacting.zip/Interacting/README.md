# Interacting

A project that expands on objects and pointers.

This project completes the following tasks:

1. Expand on the traveling assignment
2. Add complexity to the game by adding a method to the location objects we created.
3. Invoke the method whenever the player visits that location object.


Created On: July 7, 2020\
Pushed to Github: July 7, 2020

![Hundred Acre Wood Preview](https://user-images.githubusercontent.com/62450912/86829873-8fc71500-c05a-11ea-9766-a87ffdb4bacc.png)

![Interaction Preview](https://user-images.githubusercontent.com/62450912/88097230-78f5e780-cb5d-11ea-98b1-11789ba18333.png)
