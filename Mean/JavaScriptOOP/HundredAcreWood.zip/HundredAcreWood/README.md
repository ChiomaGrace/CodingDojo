# Hundred Acre Wood
A project that practices creating objects that point to each other.\

This project completes the following tasks:

* Create objects for each location on the map
* Have the objects point to each other as indicated in the diagram

Created On: July 7, 2020\
Pushed to Github: July 7, 2020

![Hundred Acre Wood Preview](https://user-images.githubusercontent.com/62450912/86829873-8fc71500-c05a-11ea-9766-a87ffdb4bacc.png)

