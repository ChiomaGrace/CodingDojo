# Traveling
A project that expands on objects and pointers.

This project completes the following tasks:

1. Create the player object with the location attribute

2. Assign the player's location to the tigger object

3. Create the function move, which takes a direction as a parameter

4. When the move function is invoked, change the player's location accordingly and log a message

5. If the move function is passed an invalid direction, log a message to inform the user

Created On: July 7, 2020\
Pushed to Github: July 7, 2020

![Hundred Acre Wood Preview](https://user-images.githubusercontent.com/62450912/86829873-8fc71500-c05a-11ea-9766-a87ffdb4bacc.png)

