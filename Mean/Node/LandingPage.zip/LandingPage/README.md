# Landing Page

This project performs the following tasks:

1. Create a small node server capable of handling the following request URLs:
    * localhost:6789/ This route should serve a view file called index.html and display a greeting.

    * localhost:6789/ninjas This route should serve a view file called ninjas.html and display information about ninjas.

    * localhost:6789/dojos/new This route should serve a view file called dojos.html and have a form (don't worry about where the form should be sent to).

Created On: September 3, 2020\
Pushed to Github: September 3, 2020