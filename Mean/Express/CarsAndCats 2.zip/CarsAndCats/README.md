# Cars and Cats

This project performs the following tasks:

1. Create cars.html, cats.html, and index.html

2. Set up your server

3. Test out the routes listed above


Start Date: July 17, 2020\
Pushed to Github: July 26, 2020