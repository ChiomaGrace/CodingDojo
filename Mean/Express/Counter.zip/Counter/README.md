# Counter

This project performs the following tasks:

1. Tests understanding of session.

2. Builds an Express application that counts the number of times the root route ('/') has been viewed by the user. 

3. Adds a +2 button underneath the counter that reloads the page and increments counter by 2 (By adding another route to handle this functionality).

4. Adds a reset button that resets the counter back to 1 (By adding another route to handle this functionality).

Start Date: September 5, 2020\
Pushed to Github: September 5, 2020