# Survey Form

This project performs the following tasks:

1. Have the server render views/index.ejs that has the form for the user to fill out

2. The user fills out the form and submits

3. The submitted form gets sent to /result

4. The server recognizes when someone posts things to /result, grabs information from the POST, and sends the POST data back as it renders views/results.ejs

Start Date: September 5, 2020\
Pushed to Github: September 5, 2020